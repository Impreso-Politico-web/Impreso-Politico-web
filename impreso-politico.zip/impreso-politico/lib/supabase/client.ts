"use client";

import { createBrowserClient } from "@supabase/ssr";

// Cliente para Client Components ('use client').
// Usa la clave anónima (segura para exponer en el navegador);
// el acceso real se controla con Row Level Security (ver supabase/schema.sql).
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
