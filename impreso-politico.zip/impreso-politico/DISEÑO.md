# Sistema de diseño — Impreso Político

Este documento explica las decisiones detrás de la identidad visual del sitio,
para que cualquier persona del equipo (o cualquier IA) pueda extenderla sin
romper su coherencia.

## Punto de partida

La portada impresa de referencia usa un lenguaje de **cartel/collage
político-juvenil**: recortes de periódico, cinta adhesiva, papel rasgado,
azul de bandera + naranja de llama, tipografía brutalista en el masthead.
Ese lenguaje funciona perfecto en una sola portada impresa, pero un sitio
web que se usa todos los días necesita poder leerse, navegarse y escanearse
con calma — no puede gritar en cada pantalla.

**La decisión central**: trasladar la *energía* del collage a un solo gesto
por vista (la portada en el hero, con un borde rasgado), y dejar que el
resto del sitio funcione con la disciplina de un diario serio — reglas
finas, tipografía con jerarquía clara, layout en grid, cero sombras
decorativas.

## Color

| Token | Hex | Uso |
|---|---|---|
| `paper` | `#ECE7DB` | Fondo general (papel periódico, no "cream" genérico) |
| `paper-dim` | `#E2DCCB` | Franjas alternas / secciones secundarias |
| `ink` | `#15140F` | Texto principal, casi negro cálido |
| `ink/soft` | `#4A473D` | Texto secundario |
| `navy` | `#1B3357` | Marca / masthead / acentos institucionales |
| `navy-dark` | `#0E1D33` | Footer, header del panel admin |
| `flame` | `#D9531E` | Único acento cálido: CTAs, enlaces activos, alertas |
| `rule` | `#C9C2AE` | Líneas finas sobre papel |

Se evitó a propósito el típico "fondo crema + acento terracota" que por
defecto producen muchas interfaces generadas por IA: el naranja aquí es más
rojo/saturado (llama editorial, no arcilla) y convive con un azul marino
dominante, no con un beige neutro.

## Tipografía

- **Serif — Source Serif 4**: titulares editoriales y cuerpo largo (hero,
  editorial, nombres de edición). Da autoridad sin caer en el
  "Playfair Display" que se ve en cualquier landing generada.
- **Sans — IBM Plex Sans**: navegación, formularios, metadatos, UI del
  panel admin. Se eligió por su carácter institucional/técnico — coherente
  con "credibilidad política" — en vez del Inter por defecto.
- **Display — Archivo Black**: *solo* para el wordmark "IMPRESO POLÍTICO" y
  el logotipo del panel admin. Es el eco contenido de la energía cartel de
  la portada; no se usa en ningún otro lugar del sitio.

## Layout

- Alineación a la **izquierda** en todo el sitio (convención de diario),
  nunca centrada.
- Retícula de 2/3/4 columnas según el viewport para la hemeroteca.
- Reglas finas (`border-t`, `border-b`) como separador principal en vez de
  tarjetas con sombra y esquinas redondeadas — así se evita el "kit de
  tarjetas SaaS" (mismo *border-radius*, misma sombra gris en todo).
- `border-radius: 0` en todo el sistema — es una decisión, no un olvido.

## Principios

1. **Un solo gesto llamativo por vista.** El borde rasgado de la portada en
   el hero es el límite; todo lo demás es disciplinado.
2. **Los números son secuencia real.** "N.º 04", "Página 3 de 24" — nunca
   se usan marcadores 01/02/03 como decoración de un proceso que no existe.
3. **Nada de chrome genérico de plantilla.** Sin eyebrows en VERSALITAS
   sobre cada título, sin "PALABRA — fragmento", sin flechas "→" pegadas a
   cada botón.
4. **El texto de la interfaz no adorna, dirige.** Los botones dicen la
   acción exacta ("Publicar edición", no "Enviar"); los estados vacíos
   explican qué hacer, no solo que "no hay nada".

## Cómo extender esto

Si agregas una vista nueva, antes de escribir CSS pregúntate: ¿esto ya
tiene un lugar bien definido en la retícula, en la paleta y en la escala
tipográfica de arriba? Si la respuesta es "necesito un color nuevo" o
"necesito una tipografía nueva", probablemente el problema es de contenido,
no de diseño — vuelve a la sección de Layout y resuélvelo con lo que ya
existe.
