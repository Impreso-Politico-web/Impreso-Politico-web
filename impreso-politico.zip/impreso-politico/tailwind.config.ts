import type { Config } from "tailwindcss";

// ─────────────────────────────────────────────────────────────
// Sistema de diseño "Impreso Político"
// Ver /DISEÑO.md para el razonamiento completo de cada decisión.
// ─────────────────────────────────────────────────────────────
const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        paper: {
          DEFAULT: "#ECE7DB", // fondo papel periódico, cálido pero no "cream cliché"
          dim: "#E2DCCB",     // franjas / secciones alternas
        },
        ink: {
          DEFAULT: "#15140F", // texto principal, casi negro cálido
          soft: "#4A473D",    // texto secundario
        },
        navy: {
          DEFAULT: "#1B3357", // azul editorial (bandera / marca)
          dark: "#0E1D33",    // footer, header fijo, hover profundo
          line: "#3F5273",    // líneas sobre fondo navy
        },
        flame: {
          DEFAULT: "#D9531E", // acento editorial (llama / CTA)
          light: "#E97A46",
        },
        rule: "#C9C2AE", // líneas finas sobre papel
      },
      fontFamily: {
        serif: ["var(--font-source-serif)", "Georgia", "serif"],
        sans: ["var(--font-plex)", "system-ui", "sans-serif"],
        display: ["var(--font-archivo-black)", "Impact", "sans-serif"],
      },
      maxWidth: {
        content: "1240px",
      },
      borderRadius: {
        none: "0px", // el sistema evita esquinas redondeadas: convención de impreso
      },
      letterSpacing: {
        tightest: "-0.03em",
      },
    },
  },
  plugins: [],
};

export default config;
