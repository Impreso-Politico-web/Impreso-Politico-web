# Impreso Político — Archivo digital

Sitio y panel de administración para "Impreso Político", la revista digital
de Acción Juvenil. Permite a los lectores explorar la edición actual y toda
la hemeroteca, y a los administradores publicar, editar o borrar números
desde un panel privado.

Ver también **[DISEÑO.md](./DISEÑO.md)** para el razonamiento completo
detrás de la identidad visual (colores, tipografías, layout).

## Stack

- **Front-end**: Next.js 14 (App Router) + TypeScript + Tailwind CSS
- **Lector**: `pdf.js` (renderizado de páginas) + `react-pageflip` (efecto
  de pasar páginas)
- **Back-end / datos**: Supabase (Postgres + Auth + Storage)

## Estructura del proyecto

```
impreso-politico/
├── app/
│   ├── page.tsx                    # Inicio (hero + adelanto de hemeroteca)
│   ├── edicion-actual/page.tsx     # Visor de la última edición publicada
│   ├── hemeroteca/page.tsx         # Grid + filtros de todas las ediciones
│   ├── hemeroteca/[id]/page.tsx    # Detalle/lectura de una edición pasada
│   ├── nosotros/page.tsx
│   ├── contacto/page.tsx
│   ├── api/contacto/route.ts       # Recibe el formulario de contacto
│   └── admin/
│       ├── page.tsx                # Login
│       └── dashboard/
│           ├── page.tsx            # Tabla de ediciones + acciones
│           ├── nueva/page.tsx      # Alta de una edición nueva
│           └── editar/[id]/page.tsx
├── components/
│   ├── layout/                     # Header, Footer
│   ├── home/Hero.tsx
│   ├── reader/                     # FlipbookViewer, FlipPage, wrapper sin SSR
│   ├── hemeroteca/                 # Grid, tarjeta, filtros
│   ├── newsletter/NewsletterForm.tsx
│   ├── contacto/ContactoForm.tsx
│   └── admin/                      # LoginForm, UploadForm, EdicionesTable, LogoutButton
├── lib/supabase/                   # Clientes de Supabase (browser + server)
├── types/edicion.ts
├── middleware.ts                   # Protege /admin/* sin sesión
└── supabase/schema.sql             # Tablas, RLS, buckets — todo en un archivo
```

## 1. Requisitos previos

- Node.js 18.18 o superior
- Una cuenta gratuita en [supabase.com](https://supabase.com)

## 2. Configurar Supabase

1. **Crea un proyecto** en el dashboard de Supabase (elige la región más
   cercana a tus lectores, ej. `us-west` o `sa-east`).
2. Abre **SQL Editor → New query**, pega el contenido completo de
   [`supabase/schema.sql`](./supabase/schema.sql) y ejecútalo. Esto crea:
   - la tabla `ediciones` (con `estado` borrador/publicado),
   - la tabla `suscriptores` (newsletter),
   - la tabla `admins` (lista de correos autorizados),
   - las políticas de seguridad a nivel de fila (RLS),
   - los buckets de Storage `portadas` y `pdfs` con sus políticas de acceso.
3. **Crea tu usuario administrador**: ve a **Authentication → Users → Add
   user**, ingresa tu correo y una contraseña.
4. **Autorízalo como administrador**: vuelve a **SQL Editor** y ejecuta:
   ```sql
   insert into public.admins (email) values ('tu-correo@ejemplo.com');
   ```
   Repite este `insert` por cada persona del equipo que deba publicar.
5. Copia tus credenciales desde **Project Settings → API**:
   - `Project URL` → será tu `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public key` → será tu `NEXT_PUBLIC_SUPABASE_ANON_KEY`

## 3. Configurar el proyecto localmente

```bash
# 1. Instala las dependencias
npm install

# 2. Copia el archivo de variables de entorno y complétalo
cp .env.example .env.local
```

Edita `.env.local` con los valores del paso anterior:

```bash
NEXT_PUBLIC_SUPABASE_URL=https://tu-proyecto.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=tu-anon-key-publica
```

```bash
# 3. Levanta el servidor de desarrollo
npm run dev
```

Abre `http://localhost:3000` para el sitio público y
`http://localhost:3000/admin` para el panel de administración.

## 4. Cómo publicar una nueva edición (flujo del administrador)

1. Entra a `/admin` con tu correo y contraseña.
2. En el dashboard, haz clic en **"+ Nueva edición"**.
3. Completa el formulario:
   - Número de edición, fecha de publicación, título, descripción/editorial,
     temas clave (separados por coma).
   - Sube la **portada** (PNG/JPG) y el **PDF** de la edición.
   - Elige el estado: **Borrador** (solo tú lo ves) o **Publicado** (ya es
     visible para todos los lectores).
4. Al guardar, los archivos se suben a Supabase Storage y la fila queda
   registrada en la tabla `ediciones`.
5. Desde la tabla del dashboard puedes en cualquier momento **publicar /
   pasar a borrador**, **editar** (incluye reemplazar portada o PDF) o
   **borrar** una edición.

La página de inicio, "Edición actual" y la hemeroteca leen directamente de
esa tabla — no hace falta ningún paso extra de "sincronizar".

## 5. Cómo funciona el lector (Flipbook)

`FlipbookViewer` (en `components/reader/`) carga el PDF con `pdf.js`,
renderiza cada página en un `<canvas>` y las entrega a `react-pageflip`
para el efecto de pasar hojas. Como ambas librerías necesitan el navegador,
se cargan a través de `FlipbookClientWrapper`, el único punto del proyecto
con `next/dynamic({ ssr: false })`.

**Nota para producción**: por simplicidad, el *worker* de `pdf.js` se carga
desde un CDN (`cdnjs.cloudflare.com`) en la versión exacta instalada. Si
prefieres no depender de un CDN externo, copia
`node_modules/pdfjs-dist/build/pdf.worker.min.mjs` a `/public/` y cambia esa
línea en `FlipbookViewer.tsx` por:
```ts
pdfjsLib.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.mjs";
```

## 6. Desplegar

La forma más simple es [Vercel](https://vercel.com) (mismo creador de
Next.js):

1. Sube este proyecto a un repositorio de GitHub.
2. En Vercel: **Add New → Project**, importa el repositorio.
3. En **Environment Variables**, agrega `NEXT_PUBLIC_SUPABASE_URL` y
   `NEXT_PUBLIC_SUPABASE_ANON_KEY` con los mismos valores de tu `.env.local`.
4. Despliega. Cada vez que hagas `git push`, Vercel vuelve a construir el
   sitio automáticamente.

No necesitas configurar nada especial para las imágenes de portada: ya
están permitidas en `next.config.js` los dominios `*.supabase.co`.

## 7. Próximos pasos sugeridos

Estas no estaban en el alcance pedido, pero son extensiones naturales:

- **Envío real del newsletter**: hoy los correos solo se guardan en la
  tabla `suscriptores`; conecta un cron/Edge Function de Supabase con un
  proveedor (Resend, Postmark) para avisar automáticamente al publicar.
- **Formulario de contacto**: `app/api/contacto/route.ts` solo registra el
  mensaje en el log del servidor; conéctalo a un proveedor de correo o a
  una tabla de Supabase.
- **Búsqueda de texto completo**: los filtros actuales comparan en el
  cliente; para una hemeroteca de cientos de números, conviene mover el
  filtrado al servidor con `textSearch` de Postgres.
- **Compartir en redes** desde cada página de edición (Open Graph con la
  portada como imagen).
