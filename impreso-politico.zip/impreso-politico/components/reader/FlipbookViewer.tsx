"use client";

import { useEffect, useRef, useState } from "react";
import HTMLFlipBook from "react-pageflip";
import type { PDFDocumentProxy } from "pdfjs-dist";
import FlipPage from "./FlipPage";

// Este componente asume que se importa con `next/dynamic` y `ssr: false`
// desde la página que lo usa (pdf.js y react-pageflip requieren `window`).
// Ver: app/edicion-actual/page.tsx

export default function FlipbookViewer({
  pdfUrl,
  titulo,
}: {
  pdfUrl: string;
  titulo: string;
}) {
  const [pdf, setPdf] = useState<PDFDocumentProxy | null>(null);
  const [numPaginas, setNumPaginas] = useState(0);
  const [paginaActual, setPaginaActual] = useState(1);
  const [zoom, setZoom] = useState(1);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState(false);

  const contenedorRef = useRef<HTMLDivElement>(null);
  const flipBookRef = useRef<HTMLFlipBook>(null);

  useEffect(() => {
    let cancelado = false;

    async function cargarPdf() {
      setCargando(true);
      setError(false);
      try {
        const pdfjsLib = await import("pdfjs-dist");
        // Worker servido desde CDN, en la misma versión que la librería
        // instalada. Alternativa para producción: copiar
        // pdf.worker.min.mjs a /public y apuntar workerSrc ahí (ver README).
        pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;

        const documento = await pdfjsLib.getDocument(pdfUrl).promise;
        if (cancelado) return;
        setPdf(documento);
        setNumPaginas(documento.numPages);
      } catch {
        if (!cancelado) setError(true);
      } finally {
        if (!cancelado) setCargando(false);
      }
    }

    cargarPdf();
    return () => {
      cancelado = true;
    };
  }, [pdfUrl]);

  function irAPaginaAnterior() {
    flipBookRef.current?.pageFlip().flipPrev();
  }

  function irAPaginaSiguiente() {
    flipBookRef.current?.pageFlip().flipNext();
  }

  function alternarPantallaCompleta() {
    if (!contenedorRef.current) return;
    if (!document.fullscreenElement) {
      contenedorRef.current.requestFullscreen?.();
    } else {
      document.exitFullscreen?.();
    }
  }

  function acercarZoom() {
    setZoom((z) => Math.min(z + 0.2, 2));
  }

  function alejarZoom() {
    setZoom((z) => Math.max(z - 0.2, 0.6));
  }

  if (cargando) {
    return (
      <div className="flex aspect-[4/3] w-full items-center justify-center bg-ink/5 font-sans text-sm text-ink/60">
        Cargando edición…
      </div>
    );
  }

  if (error || !pdf) {
    return (
      <div className="flex aspect-[4/3] w-full flex-col items-center justify-center gap-3 bg-ink/5 px-6 text-center font-sans text-sm text-ink/60">
        <p>No pudimos cargar el visor de esta edición.</p>
        <a
          href={pdfUrl}
          download
          className="font-semibold text-flame underline underline-offset-2"
        >
          Descargar el PDF directamente
        </a>
      </div>
    );
  }

  return (
    <div ref={contenedorRef} className="bg-ink/5 py-8">
      <div
        className="mx-auto flex justify-center overflow-auto px-4 transition-transform duration-200"
        style={{ transform: `scale(${zoom})`, transformOrigin: "top center" }}
        role="region"
        aria-label={`Lector de ${titulo}`}
      >
        <HTMLFlipBook
          width={420}
          height={594}
          size="stretch"
          minWidth={280}
          maxWidth={640}
          minHeight={396}
          maxHeight={900}
          maxShadowOpacity={0.4}
          showCover={true}
          mobileScrollSupport={true}
          onFlip={(e: { data: number }) => setPaginaActual(e.data + 1)}
          ref={flipBookRef}
          className="shadow-2xl"
        >
          {Array.from({ length: numPaginas }, (_, i) => (
            <FlipPage key={i} pdf={pdf} pageNumber={i + 1} />
          ))}
        </HTMLFlipBook>
      </div>

      <div className="container-editorial mt-6 flex flex-wrap items-center justify-center gap-4 font-sans text-sm text-ink">
        <button
          onClick={irAPaginaAnterior}
          className="border border-ink px-3 py-1.5 hover:border-flame hover:text-flame"
        >
          ← Anterior
        </button>
        <span>
          Página {paginaActual} de {numPaginas}
        </span>
        <button
          onClick={irAPaginaSiguiente}
          className="border border-ink px-3 py-1.5 hover:border-flame hover:text-flame"
        >
          Siguiente →
        </button>

        <span className="mx-1 h-4 w-px bg-rule" aria-hidden="true" />

        <button
          onClick={alejarZoom}
          aria-label="Alejar"
          className="border border-ink px-3 py-1.5 hover:border-flame hover:text-flame"
        >
          −
        </button>
        <span>{Math.round(zoom * 100)}%</span>
        <button
          onClick={acercarZoom}
          aria-label="Acercar"
          className="border border-ink px-3 py-1.5 hover:border-flame hover:text-flame"
        >
          +
        </button>

        <span className="mx-1 h-4 w-px bg-rule" aria-hidden="true" />

        <button
          onClick={alternarPantallaCompleta}
          className="border border-ink px-3 py-1.5 hover:border-flame hover:text-flame"
        >
          Pantalla completa
        </button>
      </div>
    </div>
  );
}
