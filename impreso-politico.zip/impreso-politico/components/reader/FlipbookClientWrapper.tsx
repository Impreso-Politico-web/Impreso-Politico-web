"use client";

import dynamic from "next/dynamic";

// pdf.js y react-pageflip dependen de APIs del navegador (window, canvas),
// así que se cargan solo del lado del cliente. Este wrapper es el único
// lugar donde se usa `ssr: false`, y por eso vive en su propio archivo
// "use client": Next.js no permite `ssr: false` dentro de Server Components.
const FlipbookViewer = dynamic(() => import("./FlipbookViewer"), {
  ssr: false,
  loading: () => (
    <div className="flex aspect-[4/3] w-full items-center justify-center bg-ink/5 font-sans text-sm text-ink/60">
      Cargando visor…
    </div>
  ),
});

export default function FlipbookClientWrapper(props: {
  pdfUrl: string;
  titulo: string;
}) {
  return <FlipbookViewer {...props} />;
}
