"use client";

import { forwardRef, useEffect, useRef } from "react";
import type { PDFDocumentProxy } from "pdfjs-dist";

interface FlipPageProps {
  pdf: PDFDocumentProxy | null;
  pageNumber: number;
}

// react-pageflip clona cada hijo y le pasa una ref al elemento raíz:
// por eso este componente usa forwardRef en vez de recibir la ref como prop.
const FlipPage = forwardRef<HTMLDivElement, FlipPageProps>(function FlipPage(
  { pdf, pageNumber },
  ref
) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    let cancelado = false;

    async function renderizarPagina() {
      if (!pdf || !canvasRef.current) return;
      const pagina = await pdf.getPage(pageNumber);
      const viewport = pagina.getViewport({ scale: 1.5 });
      const canvas = canvasRef.current;
      const contexto = canvas.getContext("2d");
      if (!contexto || cancelado) return;

      canvas.width = viewport.width;
      canvas.height = viewport.height;

      await pagina.render({ canvasContext: contexto, viewport }).promise;
    }

    renderizarPagina();
    return () => {
      cancelado = true;
    };
  }, [pdf, pageNumber]);

  return (
    <div ref={ref} className="page flex items-center justify-center bg-white">
      <canvas ref={canvasRef} className="h-full w-full object-contain" />
    </div>
  );
});

export default FlipPage;
