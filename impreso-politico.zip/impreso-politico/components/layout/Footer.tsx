import Link from "next/link";
import NewsletterForm from "@/components/newsletter/NewsletterForm";

export default function Footer() {
  return (
    <footer className="bg-navy-dark text-paper/90">
      <div className="container-editorial grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div className="lg:col-span-2">
          <p className="font-display text-xl tracking-tightest">
            IMPRESO POLÍTICO
          </p>
          <p className="mt-3 max-w-sm font-serif text-sm leading-relaxed text-paper/70">
            Una revista de Acción Juvenil. Política, juventud y realidad,
            sin filtros — un número a la vez.
          </p>
          <div className="mt-5 flex gap-4">
            <SocialLink href="https://instagram.com" label="Instagram" />
            <SocialLink href="https://x.com" label="X (Twitter)" />
            <SocialLink href="https://tiktok.com" label="TikTok" />
            <SocialLink href="https://facebook.com" label="Facebook" />
          </div>
        </div>

        <nav aria-label="Enlaces del sitio">
          <p className="kicker text-flame-light">Secciones</p>
          <ul className="mt-3 space-y-2 font-sans text-sm">
            <li><Link href="/edicion-actual" className="hover:text-flame-light">Edición actual</Link></li>
            <li><Link href="/hemeroteca" className="hover:text-flame-light">Hemeroteca</Link></li>
            <li><Link href="/nosotros" className="hover:text-flame-light">Nosotros</Link></li>
            <li><Link href="/contacto" className="hover:text-flame-light">Contacto</Link></li>
            <li><Link href="/admin" className="text-paper/50 hover:text-flame-light">Acceso administrador</Link></li>
          </ul>
        </nav>

        <div>
          <p className="kicker text-flame-light">No te pierdas ni un número</p>
          <p className="mt-3 font-sans text-sm text-paper/70">
            Recibe un aviso en tu correo cada vez que publiquemos una nueva edición.
          </p>
          <div className="mt-4">
            <NewsletterForm variant="footer" />
          </div>
        </div>
      </div>

      <div className="border-t border-navy-line">
        <div className="container-editorial flex flex-col gap-2 py-5 text-xs text-paper/50 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} Acción Juvenil. Todos los derechos reservados.</p>
          <p>Aguascalientes, México</p>
        </div>
      </div>
    </footer>
  );
}

function SocialLink({ href, label }: { href: string; label: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={label}
      className="flex h-9 w-9 items-center justify-center border border-navy-line text-paper/70 transition-colors hover:border-flame hover:text-flame-light"
    >
      <span className="font-sans text-xs font-semibold">{label[0]}</span>
    </a>
  );
}
