"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

const NAV_LINKS = [
  { href: "/", label: "Inicio" },
  { href: "/edicion-actual", label: "Edición actual" },
  { href: "/hemeroteca", label: "Hemeroteca" },
  { href: "/nosotros", label: "Nosotros" },
  { href: "/contacto", label: "Contacto" },
];

export default function Header() {
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (!query.trim()) return;
    router.push(`/hemeroteca?buscar=${encodeURIComponent(query.trim())}`);
    setSearchOpen(false);
  }

  return (
    <header className="sticky top-0 z-50 bg-paper">
      {/* Barra utilitaria: contexto de publicación, como el folio de un diario */}
      <div className="hidden bg-navy-dark text-paper/80 sm:block">
        <div className="container-editorial flex items-center justify-between py-1.5 text-xs">
          <span>Núm. 01 · Septiembre 2026 · Aguascalientes</span>
          <span className="tracking-wide">IDEAS QUE INCOMODAN</span>
        </div>
      </div>

      {/* Fila principal: wordmark + navegación */}
      <div className="rule border-b-2 border-ink">
        <div className="container-editorial flex items-center justify-between py-4">
          <Link href="/" className="flex items-baseline gap-0.5 leading-none">
            <span className="font-display text-2xl tracking-tightest text-ink sm:text-3xl">
              IMPRESO
            </span>
            <span className="font-display text-2xl tracking-tightest text-navy sm:text-3xl">
              POLÍTICO
            </span>
          </Link>

          <nav className="hidden items-center gap-7 lg:flex">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="font-sans text-sm font-medium text-ink transition-colors hover:text-flame"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <button
              aria-label="Buscar ediciones"
              onClick={() => setSearchOpen((v) => !v)}
              className="p-2 text-ink hover:text-flame"
            >
              <SearchIcon />
            </button>
            <button
              aria-label="Abrir menú"
              onClick={() => setMenuOpen((v) => !v)}
              className="p-2 text-ink hover:text-flame lg:hidden"
            >
              <MenuIcon />
            </button>
          </div>
        </div>

        {searchOpen && (
          <div className="border-t border-rule bg-paper-dim">
            <form
              onSubmit={handleSearch}
              className="container-editorial flex items-center gap-3 py-3"
            >
              <input
                autoFocus
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Buscar por título, tema o número de edición…"
                className="w-full border-b border-ink bg-transparent py-1 font-sans text-sm text-ink placeholder:text-ink/50 focus:outline-none"
              />
              <button
                type="submit"
                className="whitespace-nowrap font-sans text-sm font-semibold text-flame"
              >
                Buscar
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Menú móvil */}
      {menuOpen && (
        <nav className="border-b border-rule bg-paper lg:hidden">
          <ul className="container-editorial flex flex-col py-2">
            {NAV_LINKS.map((link) => (
              <li key={link.href} className="rule py-3 first:border-t-0">
                <Link
                  href={link.href}
                  onClick={() => setMenuOpen(false)}
                  className="font-sans text-base font-medium text-ink"
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      )}
    </header>
  );
}

function SearchIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2" />
      <path d="M21 21L16.65 16.65" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function MenuIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M4 6H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M4 12H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M4 18H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}
