"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Estado = "idle" | "cargando" | "exito" | "error";

export default function NewsletterForm({
  variant = "footer",
}: {
  variant?: "footer" | "inline";
}) {
  const [email, setEmail] = useState("");
  const [estado, setEstado] = useState<Estado>("idle");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim()) return;

    setEstado("cargando");
    const supabase = createClient();
    const { error } = await supabase
      .from("suscriptores")
      .insert({ email: email.trim().toLowerCase() });

    if (error) {
      // Código 23505 = violación de unicidad (correo ya suscrito):
      // lo tratamos como éxito para no confundir a quien ya está suscrito.
      if (error.code === "23505") {
        setEstado("exito");
      } else {
        setEstado("error");
      }
      return;
    }

    setEstado("exito");
    setEmail("");
  }

  if (estado === "exito") {
    return (
      <p
        className={
          variant === "footer"
            ? "font-sans text-sm text-paper"
            : "font-sans text-sm text-ink"
        }
      >
        Listo — te avisaremos en cuanto salga el próximo número.
      </p>
    );
  }

  const isFooter = variant === "footer";

  return (
    <form onSubmit={handleSubmit} className="flex gap-2">
      <input
        type="email"
        required
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="tu@correo.com"
        className={
          isFooter
            ? "w-full border border-navy-line bg-transparent px-3 py-2 font-sans text-sm text-paper placeholder:text-paper/40 focus:outline-none"
            : "w-full border border-ink bg-paper px-3 py-2 font-sans text-sm text-ink placeholder:text-ink/40 focus:outline-none"
        }
      />
      <button
        type="submit"
        disabled={estado === "cargando"}
        className="whitespace-nowrap bg-flame px-4 py-2 font-sans text-sm font-semibold text-paper transition-colors hover:bg-flame-light disabled:opacity-60"
      >
        {estado === "cargando" ? "Enviando…" : "Suscribirme"}
      </button>
      {estado === "error" && (
        <span className="sr-only">
          No pudimos guardar tu correo. Intenta de nuevo.
        </span>
      )}
    </form>
  );
}
