import Image from "next/image";
import Link from "next/link";
import type { Edicion } from "@/types/edicion";

function formatearFecha(fecha: string) {
  return new Intl.DateTimeFormat("es-MX", {
    month: "long",
    year: "numeric",
  }).format(new Date(fecha));
}

export default function Hero({ edicion }: { edicion: Edicion }) {
  return (
    <section className="bg-paper">
      <div className="container-editorial grid gap-10 py-12 lg:grid-cols-[1.1fr,0.9fr] lg:items-center lg:py-20">
        {/* Columna de texto */}
        <div>
          <p className="kicker">
            Edición N.º {edicion.numero} · {formatearFecha(edicion.fecha_publicacion)}
          </p>

          <h1 className="mt-4 font-serif text-4xl font-semibold leading-[1.05] tracking-tightest text-ink sm:text-5xl lg:text-6xl">
            {edicion.titulo}
          </h1>

          {edicion.descripcion && (
            <p className="mt-6 max-w-lg font-serif text-lg leading-relaxed text-ink/80">
              {edicion.descripcion}
            </p>
          )}

          {edicion.temas.length > 0 && (
            <ul className="mt-5 flex flex-wrap gap-x-4 gap-y-1 font-sans text-xs font-medium text-navy">
              {edicion.temas.map((tema) => (
                <li key={tema} className="border-b border-navy/40">
                  {tema}
                </li>
              ))}
            </ul>
          )}

          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href={`/edicion-actual`}
              className="bg-ink px-6 py-3 font-sans text-sm font-semibold text-paper transition-colors hover:bg-flame"
            >
              Leer edición actual
            </Link>
            <a
              href={edicion.pdf_url}
              download
              className="border border-ink px-6 py-3 font-sans text-sm font-semibold text-ink transition-colors hover:border-flame hover:text-flame"
            >
              Descargar PDF
            </a>
          </div>
        </div>

        {/* Portada — el único elemento con borde rasgado del sitio */}
        <div className="relative mx-auto w-full max-w-sm lg:max-w-none">
          <div className="torn-edge relative aspect-[3/4] w-full overflow-hidden bg-navy shadow-[10px_10px_0_0_theme(colors.navy.DEFAULT)]">
            <Image
              src={edicion.portada_url}
              alt={`Portada de ${edicion.titulo}`}
              fill
              priority
              className="object-cover"
              sizes="(max-width: 1024px) 90vw, 40vw"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
