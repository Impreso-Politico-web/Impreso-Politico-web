import Image from "next/image";
import Link from "next/link";
import type { Edicion } from "@/types/edicion";

function formatearFecha(fecha: string) {
  return new Intl.DateTimeFormat("es-MX", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(new Date(fecha));
}

export default function EdicionCard({ edicion }: { edicion: Edicion }) {
  return (
    <article className="group border-t-2 border-ink pt-4">
      <Link href={`/hemeroteca/${edicion.id}`} className="block">
        <div className="relative aspect-[3/4] w-full overflow-hidden bg-navy/10">
          <Image
            src={edicion.portada_url}
            alt={`Portada de ${edicion.titulo}`}
            fill
            className="object-cover transition-transform duration-300 group-hover:scale-[1.03]"
            sizes="(max-width: 640px) 45vw, (max-width: 1024px) 30vw, 22vw"
          />
        </div>
      </Link>

      <p className="mt-3 font-sans text-xs font-semibold text-flame">
        N.º {edicion.numero} · {formatearFecha(edicion.fecha_publicacion)}
      </p>

      <h3 className="mt-1 font-serif text-lg font-semibold leading-snug text-ink">
        <Link href={`/hemeroteca/${edicion.id}`} className="hover:text-navy">
          {edicion.titulo}
        </Link>
      </h3>

      {edicion.descripcion && (
        <p className="mt-1.5 line-clamp-2 font-sans text-sm text-ink/60">
          {edicion.descripcion}
        </p>
      )}

      <Link
        href={`/hemeroteca/${edicion.id}`}
        className="mt-3 inline-block font-sans text-sm font-semibold text-ink underline decoration-flame decoration-2 underline-offset-4 hover:text-flame"
      >
        Leer edición
      </Link>
    </article>
  );
}
