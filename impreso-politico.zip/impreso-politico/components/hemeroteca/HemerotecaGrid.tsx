"use client";

import { useMemo, useState } from "react";
import type { Edicion } from "@/types/edicion";
import Filtros from "./Filtros";
import EdicionCard from "./EdicionCard";

export default function HemerotecaGrid({
  ediciones,
  busquedaInicial = "",
}: {
  ediciones: Edicion[];
  busquedaInicial?: string;
}) {
  const [busqueda, setBusqueda] = useState(busquedaInicial);
  const [anio, setAnio] = useState("");
  const [mes, setMes] = useState("");

  const anios = useMemo(() => {
    const unicos = new Set(
      ediciones.map((e) => new Date(e.fecha_publicacion).getFullYear())
    );
    return Array.from(unicos).sort((a, b) => b - a);
  }, [ediciones]);

  const edicionesFiltradas = useMemo(() => {
    const texto = busqueda.trim().toLowerCase();

    return ediciones.filter((e) => {
      const fecha = new Date(e.fecha_publicacion);

      if (anio && fecha.getFullYear() !== Number(anio)) return false;
      if (mes && fecha.getMonth() + 1 !== Number(mes)) return false;

      if (texto) {
        const enTitulo = e.titulo.toLowerCase().includes(texto);
        const enTemas = e.temas.some((t) => t.toLowerCase().includes(texto));
        const enNumero = String(e.numero).includes(texto);
        if (!enTitulo && !enTemas && !enNumero) return false;
      }

      return true;
    });
  }, [ediciones, busqueda, anio, mes]);

  return (
    <div>
      <Filtros
        anios={anios}
        anioSeleccionado={anio}
        mesSeleccionado={mes}
        busqueda={busqueda}
        onAnioChange={setAnio}
        onMesChange={setMes}
        onBusquedaChange={setBusqueda}
        onLimpiar={() => {
          setAnio("");
          setMes("");
          setBusqueda("");
        }}
      />

      {edicionesFiltradas.length === 0 ? (
        <p className="py-16 text-center font-serif text-lg text-ink/60">
          No encontramos ediciones con esos filtros. Intenta con otra palabra clave o año.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-x-6 gap-y-10 py-10 sm:grid-cols-3 lg:grid-cols-4">
          {edicionesFiltradas.map((edicion) => (
            <EdicionCard key={edicion.id} edicion={edicion} />
          ))}
        </div>
      )}
    </div>
  );
}
