"use client";

const MESES = [
  "enero", "febrero", "marzo", "abril", "mayo", "junio",
  "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre",
];

export default function Filtros({
  anios,
  anioSeleccionado,
  mesSeleccionado,
  busqueda,
  onAnioChange,
  onMesChange,
  onBusquedaChange,
  onLimpiar,
}: {
  anios: number[];
  anioSeleccionado: string;
  mesSeleccionado: string;
  busqueda: string;
  onAnioChange: (v: string) => void;
  onMesChange: (v: string) => void;
  onBusquedaChange: (v: string) => void;
  onLimpiar: () => void;
}) {
  const hayFiltrosActivos = anioSeleccionado || mesSeleccionado || busqueda;

  return (
    <div className="rule flex flex-wrap items-end gap-4 border-b-2 border-ink py-6">
      <div className="flex flex-col gap-1">
        <label htmlFor="filtro-busqueda" className="font-sans text-xs font-semibold text-ink/60">
          Palabra clave
        </label>
        <input
          id="filtro-busqueda"
          type="search"
          value={busqueda}
          onChange={(e) => onBusquedaChange(e.target.value)}
          placeholder="Título o tema…"
          className="w-56 border-b border-ink bg-transparent py-1 font-sans text-sm focus:outline-none"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label htmlFor="filtro-anio" className="font-sans text-xs font-semibold text-ink/60">
          Año
        </label>
        <select
          id="filtro-anio"
          value={anioSeleccionado}
          onChange={(e) => onAnioChange(e.target.value)}
          className="border-b border-ink bg-transparent py-1 font-sans text-sm focus:outline-none"
        >
          <option value="">Todos</option>
          {anios.map((anio) => (
            <option key={anio} value={anio}>{anio}</option>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-1">
        <label htmlFor="filtro-mes" className="font-sans text-xs font-semibold text-ink/60">
          Mes
        </label>
        <select
          id="filtro-mes"
          value={mesSeleccionado}
          onChange={(e) => onMesChange(e.target.value)}
          className="border-b border-ink bg-transparent py-1 font-sans text-sm capitalize focus:outline-none"
        >
          <option value="">Todos</option>
          {MESES.map((mes, i) => (
            <option key={mes} value={i + 1}>{mes}</option>
          ))}
        </select>
      </div>

      {hayFiltrosActivos && (
        <button
          onClick={onLimpiar}
          className="font-sans text-sm font-semibold text-flame hover:underline"
        >
          Limpiar filtros
        </button>
      )}
    </div>
  );
}
