"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import type { Edicion, EstadoEdicion } from "@/types/edicion";

// Mismo formulario sirve para crear (edicionExistente = undefined)
// y para editar (edicionExistente = la fila que se está modificando).
export default function UploadForm({
  edicionExistente,
}: {
  edicionExistente?: Edicion;
}) {
  const router = useRouter();
  const esEdicion = Boolean(edicionExistente);

  const [numero, setNumero] = useState(edicionExistente?.numero.toString() ?? "");
  const [titulo, setTitulo] = useState(edicionExistente?.titulo ?? "");
  const [fecha, setFecha] = useState(
    edicionExistente?.fecha_publicacion ?? new Date().toISOString().slice(0, 10)
  );
  const [descripcion, setDescripcion] = useState(edicionExistente?.descripcion ?? "");
  const [temas, setTemas] = useState(edicionExistente?.temas.join(", ") ?? "");
  const [estado, setEstado] = useState<EstadoEdicion>(edicionExistente?.estado ?? "borrador");

  const [archivoPortada, setArchivoPortada] = useState<File | null>(null);
  const [archivoPdf, setArchivoPdf] = useState<File | null>(null);

  const [enviando, setEnviando] = useState(false);
  const [progreso, setProgreso] = useState("");
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    if (!esEdicion && (!archivoPortada || !archivoPdf)) {
      setError("Sube la portada (imagen) y el PDF de la edición.");
      return;
    }

    setEnviando(true);
    const supabase = createClient();

    try {
      let portadaUrl = edicionExistente?.portada_url ?? "";
      let pdfUrl = edicionExistente?.pdf_url ?? "";

      if (archivoPortada) {
        setProgreso("Subiendo portada…");
        const rutaPortada = `edicion-${numero}-${Date.now()}-${archivoPortada.name}`;
        const { error: errorSubida } = await supabase.storage
          .from("portadas")
          .upload(rutaPortada, archivoPortada, { upsert: true });
        if (errorSubida) throw errorSubida;

        const { data } = supabase.storage.from("portadas").getPublicUrl(rutaPortada);
        portadaUrl = data.publicUrl;
      }

      if (archivoPdf) {
        setProgreso("Subiendo PDF…");
        const rutaPdf = `edicion-${numero}-${Date.now()}-${archivoPdf.name}`;
        const { error: errorSubida } = await supabase.storage
          .from("pdfs")
          .upload(rutaPdf, archivoPdf, { upsert: true });
        if (errorSubida) throw errorSubida;

        const { data } = supabase.storage.from("pdfs").getPublicUrl(rutaPdf);
        pdfUrl = data.publicUrl;
      }

      setProgreso("Guardando datos de la edición…");

      const registro = {
        numero: Number(numero),
        titulo,
        fecha_publicacion: fecha,
        descripcion,
        temas: temas
          .split(",")
          .map((t) => t.trim())
          .filter(Boolean),
        portada_url: portadaUrl,
        pdf_url: pdfUrl,
        estado,
      };

      const { error: errorGuardado } = esEdicion
        ? await supabase.from("ediciones").update(registro).eq("id", edicionExistente!.id)
        : await supabase.from("ediciones").insert(registro);

      if (errorGuardado) throw errorGuardado;

      router.push("/admin/dashboard");
      router.refresh();
    } catch (err) {
      const mensaje = err instanceof Error ? err.message : "Ocurrió un error inesperado.";
      setError(mensaje);
      setEnviando(false);
      setProgreso("");
    }
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl space-y-6">
      <div className="grid gap-6 sm:grid-cols-2">
        <Campo label="Número de edición" htmlFor="numero">
          <input
            id="numero"
            type="number"
            required
            value={numero}
            onChange={(e) => setNumero(e.target.value)}
            className="campo-admin"
          />
        </Campo>

        <Campo label="Fecha de publicación" htmlFor="fecha">
          <input
            id="fecha"
            type="date"
            required
            value={fecha}
            onChange={(e) => setFecha(e.target.value)}
            className="campo-admin"
          />
        </Campo>
      </div>

      <Campo label="Título" htmlFor="titulo">
        <input
          id="titulo"
          type="text"
          required
          value={titulo}
          onChange={(e) => setTitulo(e.target.value)}
          className="campo-admin"
          placeholder="¿Y si nuestra generación deja de pedir permiso?"
        />
      </Campo>

      <Campo label="Descripción / editorial breve" htmlFor="descripcion">
        <textarea
          id="descripcion"
          rows={4}
          value={descripcion}
          onChange={(e) => setDescripcion(e.target.value)}
          className="campo-admin"
        />
      </Campo>

      <Campo label="Temas clave (separados por coma)" htmlFor="temas">
        <input
          id="temas"
          type="text"
          value={temas}
          onChange={(e) => setTemas(e.target.value)}
          className="campo-admin"
          placeholder="Juventud, Reforma electoral, Aguascalientes"
        />
      </Campo>

      <div className="grid gap-6 sm:grid-cols-2">
        <Campo label={`Portada (imagen)${esEdicion ? " — opcional, reemplaza la actual" : ""}`} htmlFor="portada">
          <input
            id="portada"
            type="file"
            accept="image/png,image/jpeg,image/webp"
            onChange={(e) => setArchivoPortada(e.target.files?.[0] ?? null)}
            className="campo-admin file:mr-3 file:border-0 file:bg-ink file:px-3 file:py-1.5 file:font-sans file:text-xs file:font-semibold file:text-paper"
          />
        </Campo>

        <Campo label={`PDF de la edición${esEdicion ? " — opcional, reemplaza el actual" : ""}`} htmlFor="pdf">
          <input
            id="pdf"
            type="file"
            accept="application/pdf"
            onChange={(e) => setArchivoPdf(e.target.files?.[0] ?? null)}
            className="campo-admin file:mr-3 file:border-0 file:bg-ink file:px-3 file:py-1.5 file:font-sans file:text-xs file:font-semibold file:text-paper"
          />
        </Campo>
      </div>

      <Campo label="Estado" htmlFor="estado">
        <select
          id="estado"
          value={estado}
          onChange={(e) => setEstado(e.target.value as EstadoEdicion)}
          className="campo-admin"
        >
          <option value="borrador">Borrador (solo visible para administradores)</option>
          <option value="publicado">Publicado (visible para todos los lectores)</option>
        </select>
      </Campo>

      {error && (
        <p className="border-l-4 border-flame bg-flame/10 px-4 py-3 font-sans text-sm text-ink">
          {error}
        </p>
      )}

      <div className="flex items-center gap-4">
        <button
          type="submit"
          disabled={enviando}
          className="bg-ink px-6 py-3 font-sans text-sm font-semibold text-paper hover:bg-flame disabled:opacity-60"
        >
          {enviando ? progreso || "Guardando…" : esEdicion ? "Guardar cambios" : "Publicar edición"}
        </button>
        <button
          type="button"
          onClick={() => router.push("/admin/dashboard")}
          className="font-sans text-sm text-ink/60 hover:text-ink"
        >
          Cancelar
        </button>
      </div>
    </form>
  );
}

function Campo({
  label,
  htmlFor,
  children,
}: {
  label: string;
  htmlFor: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label htmlFor={htmlFor} className="block font-sans text-xs font-semibold text-ink/60">
        {label}
      </label>
      <div className="mt-1">{children}</div>
    </div>
  );
}
