"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function LoginForm() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [enviando, setEnviando] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setEnviando(true);

    const supabase = createClient();
    const { error: errorAuth } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (errorAuth) {
      setError("Correo o contraseña incorrectos.");
      setEnviando(false);
      return;
    }

    router.push("/admin/dashboard");
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="mx-auto max-w-sm space-y-5">
      <div>
        <label htmlFor="email" className="font-sans text-xs font-semibold text-ink/60">
          Correo
        </label>
        <input
          id="email"
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="campo-admin mt-1"
        />
      </div>

      <div>
        <label htmlFor="password" className="font-sans text-xs font-semibold text-ink/60">
          Contraseña
        </label>
        <input
          id="password"
          type="password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="campo-admin mt-1"
        />
      </div>

      {error && <p className="font-sans text-sm text-flame">{error}</p>}

      <button
        type="submit"
        disabled={enviando}
        className="w-full bg-ink py-3 font-sans text-sm font-semibold text-paper hover:bg-flame disabled:opacity-60"
      >
        {enviando ? "Entrando…" : "Iniciar sesión"}
      </button>
    </form>
  );
}
