"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import type { Edicion } from "@/types/edicion";

export default function EdicionesTable({ ediciones }: { ediciones: Edicion[] }) {
  const router = useRouter();
  const [idEnProceso, setIdEnProceso] = useState<string | null>(null);

  async function alternarEstado(edicion: Edicion) {
    setIdEnProceso(edicion.id);
    const supabase = createClient();
    const nuevoEstado = edicion.estado === "publicado" ? "borrador" : "publicado";

    await supabase.from("ediciones").update({ estado: nuevoEstado }).eq("id", edicion.id);
    setIdEnProceso(null);
    router.refresh();
  }

  async function borrarEdicion(edicion: Edicion) {
    const confirmado = window.confirm(
      `¿Borrar definitivamente la edición N.º ${edicion.numero} — "${edicion.titulo}"? Esta acción no se puede deshacer.`
    );
    if (!confirmado) return;

    setIdEnProceso(edicion.id);
    const supabase = createClient();
    await supabase.from("ediciones").delete().eq("id", edicion.id);
    setIdEnProceso(null);
    router.refresh();
  }

  if (ediciones.length === 0) {
    return (
      <p className="border-t-2 border-ink py-10 font-serif text-lg text-ink/60">
        Todavía no hay ediciones. Crea la primera desde &ldquo;Nueva edición&rdquo;.
      </p>
    );
  }

  return (
    <div className="mt-6 overflow-x-auto border-t-2 border-ink">
      <table className="w-full min-w-[720px] text-left font-sans text-sm">
        <thead>
          <tr className="border-b border-rule text-xs font-semibold uppercase tracking-wide text-ink/50">
            <th className="py-3 pr-4">N.º</th>
            <th className="py-3 pr-4">Título</th>
            <th className="py-3 pr-4">Fecha</th>
            <th className="py-3 pr-4">Estado</th>
            <th className="py-3 pr-4 text-right">Acciones</th>
          </tr>
        </thead>
        <tbody>
          {ediciones.map((edicion) => (
            <tr key={edicion.id} className="border-b border-rule">
              <td className="py-3 pr-4 font-semibold">{edicion.numero}</td>
              <td className="py-3 pr-4">{edicion.titulo}</td>
              <td className="py-3 pr-4 text-ink/60">
                {new Intl.DateTimeFormat("es-MX").format(new Date(edicion.fecha_publicacion))}
              </td>
              <td className="py-3 pr-4">
                <span
                  className={
                    edicion.estado === "publicado"
                      ? "bg-navy/10 px-2 py-1 text-xs font-semibold text-navy"
                      : "bg-ink/10 px-2 py-1 text-xs font-semibold text-ink/60"
                  }
                >
                  {edicion.estado === "publicado" ? "Publicado" : "Borrador"}
                </span>
              </td>
              <td className="py-3 pr-4">
                <div className="flex items-center justify-end gap-4">
                  <button
                    onClick={() => alternarEstado(edicion)}
                    disabled={idEnProceso === edicion.id}
                    className="text-ink/70 hover:text-navy disabled:opacity-50"
                  >
                    {edicion.estado === "publicado" ? "Pasar a borrador" : "Publicar"}
                  </button>
                  <Link
                    href={`/admin/dashboard/editar/${edicion.id}`}
                    className="text-ink/70 hover:text-navy"
                  >
                    Editar
                  </Link>
                  <button
                    onClick={() => borrarEdicion(edicion)}
                    disabled={idEnProceso === edicion.id}
                    className="text-flame hover:underline disabled:opacity-50"
                  >
                    Borrar
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
