"use client";

import { useState } from "react";

type Estado = "idle" | "enviando" | "enviado" | "error";

export default function ContactoForm() {
  const [estado, setEstado] = useState<Estado>("idle");

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setEstado("enviando");

    const formData = new FormData(e.currentTarget);
    const payload = Object.fromEntries(formData.entries());

    try {
      const res = await fetch("/api/contacto", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("Error al enviar");
      setEstado("enviado");
    } catch {
      setEstado("error");
    }
  }

  if (estado === "enviado") {
    return (
      <div className="border-t-2 border-ink pt-6">
        <p className="font-serif text-lg text-ink">
          Recibimos tu mensaje. Te responderemos a la brevedad.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5 border-t-2 border-ink pt-6">
      <div>
        <label htmlFor="nombre" className="font-sans text-xs font-semibold text-ink/60">
          Nombre
        </label>
        <input
          id="nombre"
          name="nombre"
          required
          className="mt-1 w-full border-b border-ink bg-transparent py-2 font-sans text-sm focus:outline-none"
        />
      </div>

      <div>
        <label htmlFor="email" className="font-sans text-xs font-semibold text-ink/60">
          Correo
        </label>
        <input
          id="email"
          name="email"
          type="email"
          required
          className="mt-1 w-full border-b border-ink bg-transparent py-2 font-sans text-sm focus:outline-none"
        />
      </div>

      <div>
        <label htmlFor="mensaje" className="font-sans text-xs font-semibold text-ink/60">
          Mensaje
        </label>
        <textarea
          id="mensaje"
          name="mensaje"
          rows={5}
          required
          className="mt-1 w-full border-b border-ink bg-transparent py-2 font-sans text-sm focus:outline-none"
        />
      </div>

      <button
        type="submit"
        disabled={estado === "enviando"}
        className="bg-ink px-6 py-3 font-sans text-sm font-semibold text-paper hover:bg-flame disabled:opacity-60"
      >
        {estado === "enviando" ? "Enviando…" : "Enviar mensaje"}
      </button>

      {estado === "error" && (
        <p className="font-sans text-sm text-flame">
          No pudimos enviar tu mensaje. Intenta de nuevo o escríbenos directo por correo.
        </p>
      )}
    </form>
  );
}
