/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "https",
        // Reemplaza esto por el hostname real de tu proyecto Supabase,
        // ej: abcd1234.supabase.co
        hostname: "*.supabase.co",
      },
    ],
  },
};

module.exports = nextConfig;
