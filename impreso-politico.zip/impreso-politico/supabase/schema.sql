-- ─────────────────────────────────────────────────────────────
-- Impreso Político — esquema de base de datos (Supabase / Postgres)
-- Ejecutar completo en: Supabase Dashboard → SQL Editor → New query
-- ─────────────────────────────────────────────────────────────

-- 1) Tabla principal: ediciones de la revista
create table if not exists public.ediciones (
  id uuid primary key default gen_random_uuid(),
  numero integer not null unique,
  titulo text not null,
  fecha_publicacion date not null,
  descripcion text,
  temas text[] not null default '{}',
  portada_url text not null,
  pdf_url text not null,
  estado text not null default 'borrador' check (estado in ('borrador', 'publicado')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists ediciones_fecha_idx on public.ediciones (fecha_publicacion desc);
create index if not exists ediciones_estado_idx on public.ediciones (estado);

-- Mantiene updated_at al día en cada edición
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists ediciones_set_updated_at on public.ediciones;
create trigger ediciones_set_updated_at
  before update on public.ediciones
  for each row execute procedure public.set_updated_at();

-- 2) Suscriptores del newsletter
create table if not exists public.suscriptores (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  created_at timestamptz not null default now()
);

-- 3) Lista de administradores autorizados
--    (más simple que gestionar roles/claims personalizados de Auth;
--    cualquier usuario de Supabase Auth cuyo correo esté aquí puede
--    publicar, editar o borrar ediciones).
create table if not exists public.admins (
  email text primary key
);

-- Agrega aquí el correo con el que iniciarás sesión en /admin:
-- insert into public.admins (email) values ('tuequipo@accionjuvenil.mx');

-- 4) Row Level Security
alter table public.ediciones enable row level security;
alter table public.suscriptores enable row level security;
alter table public.admins enable row level security;

-- Lectura pública: cualquiera puede ver ediciones PUBLICADAS
create policy "Lectura pública de ediciones publicadas"
  on public.ediciones for select
  using (estado = 'publicado');

-- Los administradores ven todo, incluidos borradores
create policy "Administradores ven todas las ediciones"
  on public.ediciones for select
  using (auth.jwt() ->> 'email' in (select email from public.admins));

-- Solo administradores pueden insertar / editar / borrar
create policy "Administradores insertan ediciones"
  on public.ediciones for insert
  with check (auth.jwt() ->> 'email' in (select email from public.admins));

create policy "Administradores actualizan ediciones"
  on public.ediciones for update
  using (auth.jwt() ->> 'email' in (select email from public.admins));

create policy "Administradores borran ediciones"
  on public.ediciones for delete
  using (auth.jwt() ->> 'email' in (select email from public.admins));

-- Cualquiera puede suscribirse; nadie puede leer la lista desde el cliente
create policy "Cualquiera puede suscribirse"
  on public.suscriptores for insert
  with check (true);

create policy "Administradores leen suscriptores"
  on public.suscriptores for select
  using (auth.jwt() ->> 'email' in (select email from public.admins));

-- Solo lectura de la propia tabla de admins, para el propio admin autenticado
create policy "Un admin puede verificar su propio acceso"
  on public.admins for select
  using (auth.jwt() ->> 'email' = email);

-- ─────────────────────────────────────────────────────────────
-- 5) Storage: buckets para portadas y PDFs
--    (también se pueden crear desde el Dashboard → Storage → New bucket)
-- ─────────────────────────────────────────────────────────────
insert into storage.buckets (id, name, public)
values ('portadas', 'portadas', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('pdfs', 'pdfs', true)
on conflict (id) do nothing;

-- Lectura pública de ambos buckets (portadas y PDFs se muestran en la web)
create policy "Lectura pública de portadas"
  on storage.objects for select
  using (bucket_id = 'portadas');

create policy "Lectura pública de pdfs"
  on storage.objects for select
  using (bucket_id = 'pdfs');

-- Solo administradores pueden subir/editar/borrar archivos
create policy "Administradores suben portadas"
  on storage.objects for insert
  with check (bucket_id = 'portadas' and auth.jwt() ->> 'email' in (select email from public.admins));

create policy "Administradores suben pdfs"
  on storage.objects for insert
  with check (bucket_id = 'pdfs' and auth.jwt() ->> 'email' in (select email from public.admins));

create policy "Administradores borran portadas"
  on storage.objects for delete
  using (bucket_id = 'portadas' and auth.jwt() ->> 'email' in (select email from public.admins));

create policy "Administradores borran pdfs"
  on storage.objects for delete
  using (bucket_id = 'pdfs' and auth.jwt() ->> 'email' in (select email from public.admins));
