import Link from "next/link";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import Hero from "@/components/home/Hero";
import EdicionCard from "@/components/hemeroteca/EdicionCard";
import { createClient } from "@/lib/supabase/server";
import type { Edicion } from "@/types/edicion";

// Se revalida cada 5 minutos: suficiente para un archivo que publica
// cada cierto tiempo, sin regenerar la página en cada visita.
export const revalidate = 300;

export default async function HomePage() {
  const supabase = createClient();

  const { data: ultimaEdicion } = await supabase
    .from("ediciones")
    .select("*")
    .eq("estado", "publicado")
    .order("fecha_publicacion", { ascending: false })
    .limit(1)
    .maybeSingle<Edicion>();

  const { data: anteriores } = await supabase
    .from("ediciones")
    .select("*")
    .eq("estado", "publicado")
    .order("fecha_publicacion", { ascending: false })
    .range(1, 4)
    .returns<Edicion[]>();

  return (
    <>
      <Header />
      <main>
        {ultimaEdicion ? (
          <Hero edicion={ultimaEdicion} />
        ) : (
          <div className="container-editorial py-24 text-center">
            <p className="font-serif text-2xl text-ink/70">
              Todavía no hay ediciones publicadas. Vuelve pronto.
            </p>
          </div>
        )}

        {anteriores && anteriores.length > 0 && (
          <section className="rule border-t-2 border-ink bg-paper-dim">
            <div className="container-editorial py-14">
              <div className="flex items-baseline justify-between">
                <h2 className="font-serif text-2xl font-semibold text-ink">
                  Ediciones anteriores
                </h2>
                <Link
                  href="/hemeroteca"
                  className="font-sans text-sm font-semibold text-flame hover:underline"
                >
                  Ver hemeroteca completa →
                </Link>
              </div>

              <div className="mt-8 grid grid-cols-2 gap-x-6 gap-y-10 sm:grid-cols-4">
                {anteriores.map((edicion) => (
                  <EdicionCard key={edicion.id} edicion={edicion} />
                ))}
              </div>
            </div>
          </section>
        )}
      </main>
      <Footer />
    </>
  );
}
