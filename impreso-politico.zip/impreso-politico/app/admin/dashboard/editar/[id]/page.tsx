import { notFound } from "next/navigation";
import LogoutButton from "@/components/admin/LogoutButton";
import UploadForm from "@/components/admin/UploadForm";
import { createClient } from "@/lib/supabase/server";
import type { Edicion } from "@/types/edicion";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Editar edición — Panel de administración",
  robots: { index: false, follow: false },
};

export const dynamic = "force-dynamic";

export default async function EditarEdicionPage({
  params,
}: {
  params: { id: string };
}) {
  const supabase = createClient();

  const { data: edicion } = await supabase
    .from("ediciones")
    .select("*")
    .eq("id", params.id)
    .maybeSingle<Edicion>();

  if (!edicion) notFound();

  return (
    <div className="min-h-screen bg-paper">
      <header className="bg-navy-dark text-paper">
        <div className="container-editorial flex items-center justify-between py-4">
          <p className="font-display text-lg tracking-tightest">IMPRESO POLÍTICO · admin</p>
          <LogoutButton />
        </div>
      </header>

      <main className="container-editorial py-10">
        <p className="kicker">Editar</p>
        <h1 className="mt-1 font-serif text-3xl font-semibold text-ink">
          N.º {edicion.numero} — {edicion.titulo}
        </h1>

        <div className="mt-8">
          <UploadForm edicionExistente={edicion} />
        </div>
      </main>
    </div>
  );
}
