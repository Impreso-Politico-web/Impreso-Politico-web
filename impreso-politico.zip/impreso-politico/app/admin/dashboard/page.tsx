import Link from "next/link";
import LogoutButton from "@/components/admin/LogoutButton";
import EdicionesTable from "@/components/admin/EdicionesTable";
import { createClient } from "@/lib/supabase/server";
import type { Edicion } from "@/types/edicion";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Panel de administración — Impreso Político",
  robots: { index: false, follow: false },
};

export const dynamic = "force-dynamic"; // siempre datos frescos: es un panel privado

export default async function DashboardPage() {
  const supabase = createClient();

  // Gracias a RLS, un administrador autenticado ve TODAS las ediciones
  // (publicadas y borradores); un lector anónimo solo vería las publicadas.
  const { data: ediciones } = await supabase
    .from("ediciones")
    .select("*")
    .order("numero", { ascending: false })
    .returns<Edicion[]>();

  return (
    <div className="min-h-screen bg-paper">
      <header className="bg-navy-dark text-paper">
        <div className="container-editorial flex items-center justify-between py-4">
          <p className="font-display text-lg tracking-tightest">IMPRESO POLÍTICO · admin</p>
          <LogoutButton />
        </div>
      </header>

      <main className="container-editorial py-10">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="kicker">Panel de administración</p>
            <h1 className="mt-1 font-serif text-3xl font-semibold text-ink">
              Ediciones
            </h1>
          </div>
          <Link
            href="/admin/dashboard/nueva"
            className="bg-ink px-5 py-2.5 font-sans text-sm font-semibold text-paper hover:bg-flame"
          >
            + Nueva edición
          </Link>
        </div>

        <EdicionesTable ediciones={ediciones ?? []} />
      </main>
    </div>
  );
}
