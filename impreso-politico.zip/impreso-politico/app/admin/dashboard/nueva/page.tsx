import LogoutButton from "@/components/admin/LogoutButton";
import UploadForm from "@/components/admin/UploadForm";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Nueva edición — Panel de administración",
  robots: { index: false, follow: false },
};

export default function NuevaEdicionPage() {
  return (
    <div className="min-h-screen bg-paper">
      <header className="bg-navy-dark text-paper">
        <div className="container-editorial flex items-center justify-between py-4">
          <p className="font-display text-lg tracking-tightest">IMPRESO POLÍTICO · admin</p>
          <LogoutButton />
        </div>
      </header>

      <main className="container-editorial py-10">
        <p className="kicker">Publicar</p>
        <h1 className="mt-1 font-serif text-3xl font-semibold text-ink">
          Nueva edición
        </h1>

        <div className="mt-8">
          <UploadForm />
        </div>
      </main>
    </div>
  );
}
