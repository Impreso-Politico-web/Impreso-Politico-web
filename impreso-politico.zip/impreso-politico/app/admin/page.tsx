import LoginForm from "@/components/admin/LoginForm";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Acceso administrador — Impreso Político",
  robots: { index: false, follow: false },
};

export default function AdminLoginPage() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-navy-dark px-6">
      <div className="w-full max-w-sm bg-paper p-8">
        <p className="font-display text-lg tracking-tightest text-ink">
          IMPRESO POLÍTICO
        </p>
        <p className="mt-1 font-sans text-sm text-ink/60">Panel de administración</p>

        <div className="mt-8">
          <LoginForm />
        </div>
      </div>
    </main>
  );
}
