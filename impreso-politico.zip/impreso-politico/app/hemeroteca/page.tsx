import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import HemerotecaGrid from "@/components/hemeroteca/HemerotecaGrid";
import { createClient } from "@/lib/supabase/server";
import type { Edicion } from "@/types/edicion";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Hemeroteca — Impreso Político",
};

export const revalidate = 300;

export default async function HemerotecaPage({
  searchParams,
}: {
  searchParams: { buscar?: string };
}) {
  const supabase = createClient();

  const { data: ediciones } = await supabase
    .from("ediciones")
    .select("*")
    .eq("estado", "publicado")
    .order("fecha_publicacion", { ascending: false })
    .returns<Edicion[]>();

  return (
    <>
      <Header />
      <main>
        <div className="container-editorial pt-10">
          <p className="kicker">Archivo completo</p>
          <h1 className="mt-2 font-serif text-4xl font-semibold text-ink">
            Hemeroteca
          </h1>
          <p className="mt-2 max-w-xl font-sans text-ink/60">
            Todas las ediciones de Impreso Político, en un solo lugar.
          </p>
        </div>

        <div className="container-editorial pb-16">
          <HemerotecaGrid
            ediciones={ediciones ?? []}
            busquedaInicial={searchParams.buscar ?? ""}
          />
        </div>
      </main>
      <Footer />
    </>
  );
}
