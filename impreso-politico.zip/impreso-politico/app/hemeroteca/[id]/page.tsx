import { notFound } from "next/navigation";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import FlipbookClientWrapper from "@/components/reader/FlipbookClientWrapper";
import { createClient } from "@/lib/supabase/server";
import type { Edicion } from "@/types/edicion";

export const revalidate = 300;

export default async function DetalleEdicionPage({
  params,
}: {
  params: { id: string };
}) {
  const supabase = createClient();

  const { data: edicion } = await supabase
    .from("ediciones")
    .select("*")
    .eq("id", params.id)
    .eq("estado", "publicado")
    .maybeSingle<Edicion>();

  if (!edicion) notFound();

  return (
    <>
      <Header />
      <main>
        <div className="container-editorial py-10">
          <p className="kicker">N.º {edicion.numero}</p>
          <h1 className="mt-2 font-serif text-3xl font-semibold text-ink sm:text-4xl">
            {edicion.titulo}
          </h1>
          {edicion.descripcion && (
            <p className="mt-3 max-w-2xl font-serif text-lg text-ink/70">
              {edicion.descripcion}
            </p>
          )}
          <a
            href={edicion.pdf_url}
            download
            className="mt-4 inline-block font-sans text-sm font-semibold text-flame hover:underline"
          >
            Descargar PDF
          </a>
        </div>

        <FlipbookClientWrapper pdfUrl={edicion.pdf_url} titulo={edicion.titulo} />
      </main>
      <Footer />
    </>
  );
}
