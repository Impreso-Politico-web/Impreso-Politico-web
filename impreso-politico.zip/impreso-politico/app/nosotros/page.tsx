import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Nosotros — Impreso Político",
};

export default function NosotrosPage() {
  return (
    <>
      <Header />
      <main>
        <div className="container-editorial max-w-3xl py-14">
          <p className="kicker">Quiénes hacemos esto</p>
          <h1 className="mt-2 font-serif text-4xl font-semibold text-ink">
            Una revista hecha por la generación que sí se mete
          </h1>

          <div className="mt-8 space-y-5 font-serif text-lg leading-relaxed text-ink/80">
            <p>
              Impreso Político nace de Acción Juvenil como un espacio para
              analizar el país sin filtros ni discursos prefabricados. Cada
              número reúne reportajes, entrevistas y columnas escritas por
              jóvenes de todo México que decidieron dejar de ver la política
              desde afuera.
            </p>
            <p>
              No buscamos la neutralidad tibia ni el ruido fácil: buscamos
              ideas que incomoden lo suficiente para generar una conversación
              real. Creemos que la juventud no es una audiencia a la que hay
              que explicarle la política — es una generación que ya está
              construyendo el futuro del país.
            </p>
            <p>
              Este archivo digital reúne todas nuestras ediciones, desde la
              primera hasta la más reciente, para que cualquier persona pueda
              consultarlas cuando quiera, desde donde quiera.
            </p>
          </div>

          <dl className="mt-12 grid grid-cols-1 gap-8 border-t-2 border-ink pt-8 sm:grid-cols-3">
            <div>
              <dt className="kicker">Editado por</dt>
              <dd className="mt-1 font-serif text-lg text-ink">Acción Juvenil</dd>
            </div>
            <div>
              <dt className="kicker">Sede</dt>
              <dd className="mt-1 font-serif text-lg text-ink">Aguascalientes, México</dd>
            </div>
            <div>
              <dt className="kicker">Periodicidad</dt>
              <dd className="mt-1 font-serif text-lg text-ink">Mensual</dd>
            </div>
          </dl>
        </div>
      </main>
      <Footer />
    </>
  );
}
