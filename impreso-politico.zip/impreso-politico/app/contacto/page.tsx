import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import ContactoForm from "@/components/contacto/ContactoForm";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contacto — Impreso Político",
};

export default function ContactoPage() {
  return (
    <>
      <Header />
      <main>
        <div className="container-editorial grid gap-12 py-14 lg:grid-cols-2">
          <div>
            <p className="kicker">Hablemos</p>
            <h1 className="mt-2 font-serif text-4xl font-semibold text-ink">
              Contacto
            </h1>
            <p className="mt-4 max-w-md font-serif text-lg leading-relaxed text-ink/70">
              ¿Quieres colaborar con un texto, señalar un error, o proponer un
              tema para el próximo número? Escríbenos.
            </p>

            <dl className="mt-10 space-y-4 font-sans text-sm">
              <div>
                <dt className="text-ink/50">Correo editorial</dt>
                <dd className="text-ink">redaccion@impresopolitico.mx</dd>
              </div>
              <div>
                <dt className="text-ink/50">Ubicación</dt>
                <dd className="text-ink">Aguascalientes, México</dd>
              </div>
            </dl>
          </div>

          <ContactoForm />
        </div>
      </main>
      <Footer />
    </>
  );
}
