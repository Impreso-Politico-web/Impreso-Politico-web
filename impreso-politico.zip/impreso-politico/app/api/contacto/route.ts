import { NextResponse } from "next/server";

// Punto de partida: valida y registra el mensaje en los logs del servidor.
// Para producción, conecta aquí un proveedor de correo (Resend, SendGrid,
// Postmark) o guarda el mensaje en una tabla de Supabase — lo que prefieras.
export async function POST(request: Request) {
  const body = await request.json();
  const { nombre, email, mensaje } = body as {
    nombre?: string;
    email?: string;
    mensaje?: string;
  };

  if (!nombre || !email || !mensaje) {
    return NextResponse.json(
      { error: "Faltan campos obligatorios." },
      { status: 400 }
    );
  }

  // TODO: reemplazar por el envío real (proveedor de correo o base de datos).
  console.log("Nuevo mensaje de contacto:", { nombre, email, mensaje });

  return NextResponse.json({ ok: true });
}
