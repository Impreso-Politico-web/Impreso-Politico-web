import type { Metadata } from "next";
import { Source_Serif_4, IBM_Plex_Sans, Archivo_Black } from "next/font/google";
import "./globals.css";

// Serif editorial: cuerpo largo, titulares con autoridad.
const sourceSerif = Source_Serif_4({
  subsets: ["latin"],
  weight: ["400", "600", "700"],
  variable: "--font-source-serif",
  display: "swap",
});

// Sans institucional: navegación, UI, metadatos. Elegida por su carácter
// técnico/legible (diseñada para comunicación clara) en vez del Inter por defecto.
const plexSans = IBM_Plex_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-plex",
  display: "swap",
});

// Display de alto impacto: solo para el logotipo y titulares de portada,
// como eco contenido de la energía cartel/collage de la portada impresa.
const archivoBlack = Archivo_Black({
  subsets: ["latin"],
  weight: "400",
  variable: "--font-archivo-black",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Impreso Político — Una revista de Acción Juvenil",
  description:
    "Archivo digital de Impreso Político: hemeroteca completa, edición actual y análisis político hecho por y para jóvenes.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es">
      <body
        className={`${sourceSerif.variable} ${plexSans.variable} ${archivoBlack.variable}`}
      >
        {children}
      </body>
    </html>
  );
}
