export type EstadoEdicion = "borrador" | "publicado";

export interface Edicion {
  id: string;
  numero: number;
  titulo: string;
  fecha_publicacion: string; // ISO date, ej. "2026-09-01"
  descripcion: string | null;
  temas: string[]; // ej. ["Juventud", "Reforma electoral"]
  portada_url: string;
  pdf_url: string;
  estado: EstadoEdicion;
  created_at: string;
  updated_at: string;
}

// Forma que envía el formulario del panel de administración
// (los archivos se suben aparte a Supabase Storage; aquí solo
// viajan los metadatos + las URLs resultantes).
export interface EdicionInput {
  numero: number;
  titulo: string;
  fecha_publicacion: string;
  descripcion: string;
  temas: string[];
  portada_url: string;
  pdf_url: string;
  estado: EstadoEdicion;
}
